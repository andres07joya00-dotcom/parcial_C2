var annotated_dup =
[
    [ "DispositivoInteligente", "classDispositivoInteligente.html", "classDispositivoInteligente" ]
];