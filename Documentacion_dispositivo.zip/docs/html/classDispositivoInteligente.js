var classDispositivoInteligente =
[
    [ "DispositivoInteligente", "classDispositivoInteligente.html#af6a2734e2a6fae0d29f2372d10a29168", null ],
    [ "apagar", "classDispositivoInteligente.html#a58c7f163fb0404b404ceb7d84182acdb", null ],
    [ "bloquearControlRemoto", "classDispositivoInteligente.html#abe57fba78044f1065b5975fb9ffc5004", null ],
    [ "desbloquearControlRemoto", "classDispositivoInteligente.html#aa2a0ef84a8489cacb733554f83883635", null ],
    [ "encender", "classDispositivoInteligente.html#a5dcf3eac891de25539f6f1550e9823d8", null ],
    [ "medirConsumo", "classDispositivoInteligente.html#ad70c6b74a90e40b513a5707a93de6cc6", null ],
    [ "mostrarInfo", "classDispositivoInteligente.html#a3c473388c4da1f1a5ae8694450f34161", null ],
    [ "obtenerNombre", "classDispositivoInteligente.html#a6e4c963139d86f6e95562389d11dacb1", null ]
];