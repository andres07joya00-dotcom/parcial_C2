var searchData=
[
  ['apagar_0',['apagar',['../classDispositivoInteligente.html#a58c7f163fb0404b404ceb7d84182acdb',1,'DispositivoInteligente']]]
];
