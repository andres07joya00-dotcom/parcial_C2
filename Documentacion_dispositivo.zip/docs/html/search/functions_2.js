var searchData=
[
  ['desbloquearcontrolremoto_0',['desbloquearControlRemoto',['../classDispositivoInteligente.html#aa2a0ef84a8489cacb733554f83883635',1,'DispositivoInteligente']]],
  ['dispositivointeligente_1',['DispositivoInteligente',['../classDispositivoInteligente.html#af6a2734e2a6fae0d29f2372d10a29168',1,'DispositivoInteligente']]]
];
