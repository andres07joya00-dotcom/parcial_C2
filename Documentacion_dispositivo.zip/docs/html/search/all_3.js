var searchData=
[
  ['encender_0',['encender',['../classDispositivoInteligente.html#a5dcf3eac891de25539f6f1550e9823d8',1,'DispositivoInteligente']]]
];
