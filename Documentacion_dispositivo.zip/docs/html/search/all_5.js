var searchData=
[
  ['obtenernombre_0',['obtenerNombre',['../classDispositivoInteligente.html#a6e4c963139d86f6e95562389d11dacb1',1,'DispositivoInteligente']]]
];
