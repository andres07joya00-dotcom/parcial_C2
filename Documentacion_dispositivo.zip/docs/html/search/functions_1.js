var searchData=
[
  ['bloquearcontrolremoto_0',['bloquearControlRemoto',['../classDispositivoInteligente.html#abe57fba78044f1065b5975fb9ffc5004',1,'DispositivoInteligente']]]
];
